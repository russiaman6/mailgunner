package main

import (
    "bufio"
    "context"
    "fmt"
    "github.com/chromedp/chromedp"
    "log"
    "os"
    "strings"
    "sync"
    "time"
    "golang.org/x/sys/windows"
)

// ANSI color codes
const (
    Red   = "\033[31m"
    Green = "\033[32m"
    Reset = "\033[0m"
)

func init() {
    enableVirtualTerminalProcessing()
}

func main() {
    displayBanner()

    logFile, err := os.OpenFile("log.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
    if err != nil {
        fmt.Printf("Failed to create log file: %v\n", err)
        return
    }
    defer logFile.Close()
    log.SetOutput(logFile)

    fmt.Println("Press Enter to start...")
    fmt.Scanln()

    emails, err := readEmails("email.txt")
    if err != nil {
        log.Fatalf("Failed to read emails: %v\n", err)
    }

    proxies, err := readProxies("proxies.txt")
    if err != nil {
        log.Fatalf("Failed to read proxies: %v\n", err)
    }

    // Run parallel connections for each proxy
    var wg sync.WaitGroup
    emailChan := make(chan string) // Channel to send emails to goroutines

    // Start 5 parallel proxy workers
    for i := 0; i < 5 && i < len(proxies); i++ {
        wg.Add(1)
        go proxyWorker(proxies[i], emailChan, &wg)
    }

    // Send emails to the workers via the channel
    for _, email := range emails {
        emailChan <- email
    }

    close(emailChan) // Close the channel when done sending emails
    wg.Wait()        // Wait for all workers to finish
}

func proxyWorker(proxy string, emailChan <-chan string, wg *sync.WaitGroup) {
    defer wg.Done()
    for email := range emailChan {
        err := checkEmailWithProxy(proxy, email)
        if err != nil {
            log.Printf("Error with proxy %s for email %s: %v\n", proxy, email, err)
        }
    }
}

func displayBanner() {
    banner := 
	'███████╗████████╗██╗   ██╗██████╗  ██████╗ ',
    '██╔════╝╚══██╔══╝██║   ██║██╔══██╗██╔════╝ ',
    '███████╗   ██║   ██║   ██║██████╔╝██║  ███╗',
    '╚════██║   ██║   ██║   ██║██╔══██╗██║   ██║',
    '███████║   ██║   ╚██████╔╝██████╔╝╚██████╔╝',
    '╚══════╝   ╚═╝    ╚═════╝ ╚═════╝  ╚═════╝ ',
    '   MAILGUN CHECKER by @thugger70'
    fmt.Println(banner)
}

func checkEmailWithProxy(proxy, email string) error {
    proxyURL, ip, err := parseProxy(proxy)
    if err != nil {
        return fmt.Errorf("invalid proxy format: %v", err)
    }

    opts := append(chromedp.DefaultExecAllocatorOptions[:],
        chromedp.Flag("headless", true),
        chromedp.Flag("disable-gpu", true),
        chromedp.Flag("no-sandbox", true),
        chromedp.Flag("disable-logging", true),
        chromedp.Flag("proxy-server", proxyURL),
    )

    ctx, cancel := chromedp.NewExecAllocator(context.Background(), opts...)
    defer cancel()

    ctx, cancel = chromedp.NewContext(ctx)
    defer cancel()

    ctx, cancel = context.WithTimeout(ctx, 120*time.Second)
    defer cancel()

    emailSelector := #username
    nextButtonSelector := #next
    errorMessageSelector := span.loginForm__statusText

    err = chromedp.Run(ctx,
        chromedp.Navigate("https://login.mailgun.com/login"),
        chromedp.WaitVisible(emailSelector, chromedp.ByID),
        chromedp.SendKeys(emailSelector, email, chromedp.ByID),
        chromedp.Click(nextButtonSelector, chromedp.ByID),
        chromedp.Sleep(3*time.Second),
    )
    if err != nil {
        return fmt.Errorf("navigation failed: %v", err)
    }

    var response string
    err = chromedp.Run(ctx,
        chromedp.Text(errorMessageSelector, &response, chromedp.NodeVisible),
    )
    if err != nil {
        response = ""
    }

    if response == "" {
        displayStatus("MAILGUN USER", "VALID", email, ip, Green)
        saveResult("valid.txt", email)
    } else {
        displayStatus("NON MAILGUN USER", "INVALID", email, ip, Red)
        saveResult("invalid.txt", email)
    }

    return nil
}

func parseProxy(proxy string) (string, string, error) {
    parts := strings.Split(proxy, ":")
    if len(parts) < 4 {
        return "", "", fmt.Errorf("proxy format is incorrect")
    }

    ip := parts[0]
    port := parts[1]
    username := parts[2]
    password := parts[3]

    proxyURL := fmt.Sprintf("http://%s:%s@%s:%s", username, password, ip, port)
    return proxyURL, ip, nil
}

func readEmails(filename string) ([]string, error) {
    file, err := os.Open(filename)
    if err != nil {
        return nil, err
    }
    defer file.Close()

    var emails []string
    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        email := strings.TrimSpace(scanner.Text())
        if email != "" {
            emails = append(emails, email)
        }
    }

    if err := scanner.Err(); err != nil {
        return nil, err
    }
    return emails, nil
}

func readProxies(filename string) ([]string, error) {
    file, err := os.Open(filename)
    if err != nil {
        return nil, err
    }
    defer file.Close()

    var proxies []string
    scanner := bufio.NewScanner(file)
    for scanner.Scan() {
        proxy := strings.TrimSpace(scanner.Text())
        if proxy != "" {
            proxies = append(proxies, proxy)
        }
    }

    if err := scanner.Err(); err != nil {
        return nil, err
    }
    return proxies, nil
}

func saveResult(filename, email string) {
    file, err := os.OpenFile(filename, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
    if err != nil {
        log.Printf("Failed to open %s: %v\n", filename, err)
        return
    }
    defer file.Close()

    if _, err := file.WriteString(email + "\n"); err != nil {
        log.Printf("Failed to write to %s: %v\n", filename, err)
    }
}

func displayStatus(userType, status, email, ip, color string) {
    statusText := fmt.Sprintf("%s%s%s", color, status, Reset)
    statusLine := fmt.Sprintf("│ %-7s │ %s │", statusText, email)
    boxWidth := max(40, len(statusLine)-4)
    border := strings.Repeat("━", boxWidth)

    fmt.Printf(
┏%s┓
│ %-*s │ %s
┣%s┫
%s
┣%s┫
, border, boxWidth-17, userType, ip, border, statusLine, border)
}

func max(a, b int) int {
    if a > b {
        return a
    }
    return b
}

// Enable ANSI color support on Windows
func enableVirtualTerminalProcessing() {
    handle := windows.Handle(os.Stdout.Fd())
    var mode uint32
    windows.GetConsoleMode(handle, &mode)
    mode |= windows.ENABLE_VIRTUAL_TERMINAL_PROCESSING
    windows.SetConsoleMode(handle, mode)
}