<?php

$api = "6860182182:AAFfK1oJ0Xe3wIYxxo0Pfg87D_kmXdA-0VM";  // Replace with your bot's API token.
$chat_id = "1236415540";  // Replace with your Telegram chat ID.
$filename = "valid.txt";  // The file to be sent.

if (file_exists($filename)) {
    $post = [
        'chat_id' => $chat_id,
        'document' => new CURLFile($filename)
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://api.telegram.org/bot$api/sendDocument");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    $response = curl_exec($ch);
    curl_close($ch);

    echo "Response: $response\n";
} else {
    echo "Error: File $filename not found.\n";
}
?>
